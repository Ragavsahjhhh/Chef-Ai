
'use client';

import * as React from 'react';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
} from '@/components/ui/sidebar';
import { Header } from '@/components/layout/header';
import { SidebarNav } from '@/components/layout/sidebar-nav';
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/ui/avatar';
import { LogOut, ChefHat, User } from 'lucide-react';
import { ThemeProvider } from 'next-themes';

export function MainLayout({ children }: { children: React.ReactNode }) {

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <SidebarProvider>
        <div className="flex min-h-screen">
          <AppSidebar />
          <div className="flex-1 flex flex-col">
            <Header />
            <main className="p-4 sm:p-6 lg:p-8 flex-1">{children}</main>
          </div>
        </div>
      </SidebarProvider>
    </ThemeProvider>
  );
}

function AppSidebar() {
  return (
    <Sidebar
      className="border-r bg-sidebar text-sidebar-foreground"
    >
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 text-primary p-2 rounded-lg">
            <ChefHat className="h-6 w-6" />
          </div>
          <div className="group-data-[state=expanded]:block hidden">
            <h2 className="text-lg font-bold font-headline">ChefAI</h2>
            <p className="text-xs text-muted-foreground">
              Your AI Cooking Companion
            </p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarNav />
      </SidebarContent>
      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 w-full">
           <Avatar className="h-9 w-9 bg-primary/10">
              <AvatarFallback>
                <User className="text-primary" />
              </AvatarFallback>
            </Avatar>
          <div className="flex-1 group-data-[state=expanded]:block hidden">
            <p className="text-sm font-semibold">Chef Sarah</p>
            <p className="text-xs text-muted-foreground">
              sarah.chef@example.com
            </p>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
