import { config } from 'dotenv';
config();

import '@/ai/flows/generate-recipe-from-ingredients.ts';

    