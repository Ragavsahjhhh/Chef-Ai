
import React, { useEffect, useState } from "react";
import yaml from "js-yaml";
import ReactMarkdown from "react-markdown";

const Landing: React.FC = () => {
  const [config, setConfig] = useState<any>(null);
  const [content, setContent] = useState<string>("");
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    // Load YAML config
    fetch("/src/pages/landing-config.yaml")
      .then((res) => res.text())
      .then((text) => setConfig(yaml.load(text)));
    // Load Markdown content
    fetch("/src/pages/landing-content.md")
      .then((res) => res.text())
      .then(setContent);
    // Load JSON data
    fetch("/src/pages/landing-data.json")
      .then((res) => res.json())
      .then(setData);
  }, []);

  if (!config || !data) return <div className="flex items-center justify-center min-h-screen">Loading...</div>;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-100 to-purple-200 p-8">
      <h1 className="text-5xl font-bold mb-4 text-purple-700">{config.title}</h1>
      <p className="text-lg mb-6 text-gray-700">{config.subtitle}</p>
      <div className="prose max-w-xl mb-8">
        <ReactMarkdown>{content}</ReactMarkdown>
      </div>
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-2 text-purple-600">Features</h2>
        <ul className="list-disc list-inside text-gray-700">
          {data.features && data.features.map((f: string, i: number) => (
            <li key={i}>{f}</li>
          ))}
        </ul>
        <div className="mt-4 text-center">
          <a href="/signup" className="inline-block bg-purple-600 text-white px-6 py-2 rounded shadow hover:bg-purple-700 transition">{data.cta}</a>
        </div>
      </div>
      <footer className="text-xs text-gray-500">{config.footer}</footer>
    </div>
  );
};

export default Landing;
